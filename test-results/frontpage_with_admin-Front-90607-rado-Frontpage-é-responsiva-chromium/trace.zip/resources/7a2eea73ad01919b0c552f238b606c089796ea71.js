(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_def1a655._.js",
  "static/chunks/node_modules_3c5c4cad._.js"
],
    source: "dynamic"
});
