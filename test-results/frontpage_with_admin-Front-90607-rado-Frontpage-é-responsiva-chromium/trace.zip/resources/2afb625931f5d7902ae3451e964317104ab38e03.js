(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__06dbc1e2._.css",
  "static/chunks/_c2462f01._.js",
  "static/chunks/node_modules_f8d85618._.js"
],
    source: "dynamic"
});
